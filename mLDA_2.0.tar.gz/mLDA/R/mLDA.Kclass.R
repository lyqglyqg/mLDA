mLDA.Kclass <-
function(X, y, X.new, Z=NULL, COV=NULL, COR=NULL, K=3, tau=20, alpha=0.5, nu=100, d=10){

    p <- dim(X)[2]
    n <- dim(X)[1]

    if(length(y)!=n){
        stop("X and Y contain different number of samples!!")
     }
    if(dim(X.new)[2]!=p){
        stop("The test data do not contain the same number of features as the training data!!")
     }
    
    if(is.null(COV)){
	COV <- utils::globalVariables(cov(X))
    }
  
    if(is.null(COR)){
	COR <- utils::globalVariables(cor(X))
    }


    ISmatrix <- matrix(0, p, (K*(K-1)/2))

	MImatrix <- matrix(0, tau, (K*(K-1)/2))
	conn_Array <- array(0, dim=c(tau, p, (K*(K-1)/2)))

    for(k1 in 2:K){
   	 for(k in 1:(k1-1)){
   	    tmp <- mLDA.pair(X, y, X.new, Z=Z, COV=COV, COR=COR, pair=c(k,k1), tau=tau, alpha=alpha, nu=nu, d=d)     
 		ISmatrix[as.numeric(names(tmp$iffcond)), ((k1-1)*(k1-2)/2+k)] <- tmp$iffcond
		MImatrix[,((k1-1)*(k1-2)/2+k)] <- tmp$MIset
		conn_Array[,,((k1-1)*(k1-2)/2+k)] <- tmp$connMatrix
	  }
    }

    nu.vec.tmp <- NULL
    for(k in 1:K){
         nu.vec.tmp <- c(nu.vec.tmp, ISmatrix[which(ISmatrix[,1]!=0), k])
    }

    nu.value <- sort(nu.vec.tmp, decreasing=TRUE)[nu]

    ISmatrix[which(ISmatrix<nu.value, arr.ind=TRUE)] <- 0
    Sset <- which(apply(ISmatrix, 1, function(x) sum(abs(x)))!=0)
    ISmatrix.o <- ISmatrix[Sset, ]

    Sset.tmp <- apply(ISmatrix, 1, function(x) sum(abs(x)))[Sset]
    names(Sset.tmp) <- Sset
    Sset.order <- sort(Sset.tmp, decreasing=TRUE)

    mean.cis.mat <- NULL

    for(k in 1:K){
       id <- which(y==k)
       X.k <- X[id, Sset]
       mean.cis.vec <- apply(X.k, 2, mean)
       mean.cis.mat <- cbind(mean.cis.mat, mean.cis.vec)
    }

    COV.cis.mat <- COV[Sset, Sset]
    Omega.cis.mat <-  my.inv(COV.cis.mat)

    Fisher.matrix <- NULL

    for(i in 1:dim(X.new)[1]){
       X.new.cis.i <- X.new[i, Sset]
       Fisher.vec <- NULL
       for(k in 1:K){
           Fisher.ik <- (X.new.cis.i-mean.cis.mat[,k]/2)%*%Omega.cis.mat%*%mean.cis.mat[,k]
           Fisher.vec <- c(Fisher.vec, Fisher.ik)
       }
       Fisher.matrix <- rbind(Fisher.matrix, Fisher.vec)
    }

    row.names(Fisher.matrix) <- c(1:(dim(X.new)[1]))

    predClass <- apply(Fisher.matrix, 1, which.max)


    result <- list(ISmatrix=ISmatrix.o, screenset=Sset, Fisher.matrix=Fisher.matrix, PredClass=predClass, MImatrix=MImatrix, conn_Array=conn_Array, Omega.cis.mat = Omega.cis.mat)

    result


}



