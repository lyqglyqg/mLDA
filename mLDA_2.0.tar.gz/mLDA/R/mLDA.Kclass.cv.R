mLDA.Kclass.cv <-
function(X, y, COV=NULL, COR=NULL, K=3, fold=5, tau.list=c(1, 10, 20, 100, 200), alpha=0.5, nu.list=c(20, 100, 200), d=10){

	n <- dim(X)[1]
    if(length(y)!=n){
        stop("X and Y contain different number of samples!!")
     }

	
	Ky <- length(table(y))
	if(Ky!=K){	
		stop(paste("The number of classes in y is not ", K, "!!", sep=""))
	}
    
    for(k in 1:K){
    	id <- which(y==k)
    	if(length(id)==0){
			stop(paste("There is no y entries labeled as ", k, "!!", sep=""))
		}
    }


    if(is.null(COV)){
		COV <- cov(X)
    }
  
    if(is.null(COR)){
		COR <- cor(X)
    }

	COR[which(abs(COR)<alpha, arr.ind=TRUE)] <- 0

######

	IdxM <- cbind(y, rep(0, n))

	for(k in 1:K){
		id <- which(y==k)	
		reId <- sample(id, length(id), replace=FALSE)
		f.n=floor(length(id)/fold)

		for (f in 1:(fold-1)){  
			tmp.id <-reId[(f-1)*f.n+1:f.n]
			IdxM[tmp.id, 2] <- f	
    	} 

		tmp.id <-reId[((fold-1)*f.n+1):length(reId)]
		IdxM[tmp.id, 2] <- fold	
	}

####

	clsErr.M <- matrix(0, length(tau.list), length(nu.list))

	for(i in 1:length(tau.list)){
		tau.cur <- tau.list[i]
		for(j in 1:length(nu.list)){
			nu.cur <- nu.list[j]
			
			print(paste("tau=", tau.cur, "; nu=", nu.cur, sp=""))
			for(f in 1:fold){
				print(paste("fold=",f))   
				
				X.train <- X[which(IdxM[,2]!=f),]
				y.train <- y[which(IdxM[,2]!=f)]
				X.test <- X[which(IdxM[,2]==f),]
				y.test <- y[which(IdxM[,2]==f)]

				tmp.f <- mLDA.Kclass(X.train, y.train, X.test, COV=COV, COR=COR, K=K, tau=tau.cur, alpha=alpha, nu=nu.cur, d=d)				
				clsErr.test <- sum(abs(tmp.f$PredClass-y.test))
				clsErr.M[i,j] <- clsErr.M[i,j] + clsErr.test					
  								
			}# end of for(f in 1:fold)
		}
	}


	rownames(clsErr.M)=paste("tau=", tau.list)
	colnames(clsErr.M)=paste("nu=", nu.list)

	return(clsErr.M)

}
