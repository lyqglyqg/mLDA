mLDA.pair.cv <-
function(X, y, COV=NULL, COR=NULL, pair=c(1,2), fold=5, tau.list=c(1, 10, 20, 100, 200), alpha=0.5, nu.list=c(20, 100, 200), d=10){

	n <- dim(X)[1]
    if(length(y)!=n){
        stop("X and Y contain different number of samples!!")
     }


    id1<- which(y==pair[1])
    if(length(id1)==0){
		stop(paste("There is no y entries labeled as ", pair[1], "!", sep=""))
	}

    id2<- which(y==pair[2])
    if(length(id2)==0){
		stop(paste("There is no y entries labeled as ", pair[2], "!", sep=""))
	}


    if(is.null(COV)){
	COV <- cov(X)
    }
  
    if(is.null(COR)){
	COR <- cor(X)
    }
	COR[which(abs(COR)<alpha, arr.ind=TRUE)] <- 0

	indexId1.cv<-NULL
	indexId2.cv<-NULL
	reId1 <- sample(id1, length(id1), replace=FALSE)
	reId2 <- sample(id2, length(id2), replace=FALSE)
	f1.n=floor(length(id1)/fold)
	f2.n=floor(length(id2)/fold)
	for (f in 1:(fold-1)){  
	     indexId1.cv[[f]]<-reId1[(f-1)*f1.n+1:f1.n]
	     indexId2.cv[[f]]<-reId2[(f-1)*f2.n+1:f1.n]  
    } 
	indexId1.cv[[fold]]<-reId1[((fold-1)*f1.n+1):length(reId1)]
	indexId2.cv[[fold]]<-reId2[((fold-1)*f2.n+1):length(reId2)]

	clsErr.M <- matrix(0, length(tau.list), length(nu.list))


	for(f in 1:fold){
		print(paste("fold=",f))   
		indexId1.cur.cv<-indexId1.cv[[f]]
		indexId2.cur.cv<-indexId2.cv[[f]]	
		indexId1.cur.cv.train <- id1[is.na(pmatch(id1,indexId1.cur.cv))]
		indexId2.cur.cv.train <- id2[is.na(pmatch(id2,indexId2.cur.cv))]
			   
		X.train <-X[c(indexId1.cur.cv.train, indexId2.cur.cv.train),]   
		y.train <- c(rep(0,length(indexId1.cur.cv.train)),  rep(1,length(indexId2.cur.cv.train)))
	    X.test<-X[c(indexId1.cur.cv, indexId2.cur.cv),]   
	    y.test<-c(rep(0, length(indexId1.cur.cv)), rep(1, length(indexId2.cur.cv)))   

		for(i in 1:length(tau.list)){
			tau <- tau.list[i]

			meanDiff <- apply(as.matrix(X.train[which(y.train==0),]), 2, mean) - apply(as.matrix(X.train[which(y.train==1),]), 2, mean)
			meanDiffRank <- order(-abs(meanDiff))
			meanDiff_firstTau <- meanDiffRank[1:tau]

			meanAvg <- (apply(as.matrix(X.train[which(y.train==0),]), 2, mean) + apply(as.matrix(X.train[which(y.train==1),]), 2, mean))/2

			Omega <- matrix(0, p, p)

			vis=rep(0, p)
			id <- meanDiff_firstTau[1]
			scr <- meanDiff_firstTau
			while(!is.na(id)){
				tmp <- con_node(id, COR, visited=vis, m=d)
				con_set <- tmp$connect
				vis <- tmp$visited
				Omega[con_set, con_set] <- qr.solve(COV[con_set, con_set])
				id <- scr[is.na(match(scr, con_set))][1]
				scr <- scr[is.na(match(scr, con_set))]
			}

			screenID <- which(apply(Omega, 1, sum)!=0)
			Omega.s <- Omega[screenID, screenID]

			meanDiff.s <- meanDiff[screenID]
			iffcond.s <- as.vector(Omega.s%*%meanDiff.s)
			names(iffcond.s) <- screenID
			iffcond.s_order <- sort(abs(iffcond.s), decreasing=TRUE)

			for(j in 1:length(nu.list)){
				nu <- nu.list[j]
			
		    	if(length(iffcond.s_order)>nu){
					screenID2 <- as.numeric(names(iffcond.s_order)[1:nu])
				}else{
		 			screenID2 <- as.numeric(names(iffcond.s_order))
		    	}
				meanAvg.s <- meanAvg[screenID2] 
				Omega.s2 <- Omega[screenID2, screenID2] 
				meanDiff.s2 <- meanDiff[screenID2]

				X.test.s <- X.test[,screenID2]
				if(length(screenID2)==1){
					meanAvg.s <- as.vector(meanAvg.s)
					X.test.s <- as.matrix(X.test.s)
					meanAvg.s.m <- matrix(rep(meanAvg.s, dim(X.test.s)[1]), dim(X.test.s)[1], length(meanAvg.s), byrow=TRUE)
				}else{
					meanAvg.s.m <- matrix(rep(meanAvg.s, dim(X.test.s)[1]), dim(X.test.s)[1], length(meanAvg.s), byrow=TRUE)
				}

				FisherDR.test <- (X.test.s-meanAvg.s.m)%*%Omega.s2%*%meanDiff.s2
 				testClass <- 1-(FisherDR.test>=0)
				clsErr.test <- sum(abs(testClass-y.test))

				clsErr.M[i,j] <- clsErr.M[i,j] + clsErr.test					
			}
		}
	}
	
	rownames(clsErr.M)=paste("tau=", tau.list)
	colnames(clsErr.M)=paste("nu=", nu.list)

	return(clsErr.M)
}
