mLDA.pair <-
function(X, y, X.new, COV=NULL, COR=NULL, pair=c(1,2), tau=200, alpha=0.5, nu=100, d=10){
  
    p <- dim(X)[2]
    n <- dim(X)[1]

    if(length(y)!=n){
        stop("X and Y contain different number of samples!!")
     }
    if(dim(X.new)[2]!=p){
        stop("The test data do not contain the same number of features as the training data!!")
     }

    id1<- which(y==pair[1])
    if(length(id1)==0){
		stop(paste("There is no y entries labeled as ", pair[1], "!", sep=""))
	}

    id2<- which(y==pair[2])
    if(length(id2)==0){
		stop(paste("There is no y entries labeled as ", pair[2], "!", sep=""))
	}

	y12 <- c(rep(0, length(id1)), rep(1, length(id2)))
	X12 <- X[c(id1, id2),]
    
    if(is.null(COV)){
	COV <- cov(X)
    }
  
    if(is.null(COR)){
	COR <- cor(X)
    }


	COR[which(abs(COR)<alpha, arr.ind=TRUE)] <- 0


	meanDiff <- apply(as.matrix(X12[which(y12==0),]), 2, mean) - apply(as.matrix(X12[which(y12==1),]), 2, mean)
	meanDiffRank <- order(-abs(meanDiff))
	meanDiff_firstTau <- meanDiffRank[1:tau]

	meanAvg <- (apply(as.matrix(X12[which(y12==0),]), 2, mean) + apply(as.matrix(X12[which(y12==1),]), 2, mean))/2

	Omega <- matrix(0, p, p)

	vis=rep(0, p)
	id <- meanDiff_firstTau[1]
	scr <- meanDiff_firstTau
	while(!is.na(id)){
		tmp <- con_node(id, COR, visited=vis, m=d)
		con_set <- tmp$connect
		vis <- tmp$visited
		Omega[con_set, con_set] <- qr.solve(COV[con_set, con_set])
		id <- scr[is.na(match(scr, con_set))][1]
		scr <- scr[is.na(match(scr, con_set))]
	}

	screenID <- which(apply(Omega, 1, sum)!=0)
	Omega.s <- Omega[screenID, screenID]

	meanDiff.s <- meanDiff[screenID]
	iffcond.s <- as.vector(Omega.s%*%meanDiff.s)
	names(iffcond.s) <- screenID
	iffcond.s_order <- sort(abs(iffcond.s), decreasing=TRUE)

    if(length(iffcond.s_order)>nu){
		screenID2 <- as.numeric(names(iffcond.s_order)[1:nu])
	}else{
 		screenID2 <- as.numeric(names(iffcond.s_order))
    }
	meanAvg.s <- meanAvg[screenID2] 
	Omega.s2 <- Omega[screenID2, screenID2] 
	meanDiff.s2 <- meanDiff[screenID2]

	X.new.s <- X.new[,screenID2]
	if(length(screenID2)==1){
		meanAvg.s <- as.vector(meanAvg.s)
		X.new.s <- as.matrix(X.new.s)
		meanAvg.s.m <- matrix(rep(meanAvg.s, dim(X.new.s)[1]), dim(X.new.s)[1], length(meanAvg.s), byrow=TRUE)
	}else{
		meanAvg.s.m <- matrix(rep(meanAvg.s, dim(X.new.s)[1]), dim(X.new.s)[1], length(meanAvg.s), byrow=TRUE)
	}

	FisherDR <- 
	FisherDR <- (X.new.s-meanAvg.s.m)%*%Omega.s2%*%meanDiff.s2
 	PredClass <- (FisherDR>=0)

	result <- list(iffcond=iffcond.s_order, screenset=screenID2, FisherDR=FisherDR, PredClass=PredClass)

    result
}
