con_node <-
function(vid, Sig, visited=rep(0, dim(Sig)[1]), depth=0, m=10, connect=NULL, path=NULL){
         
     if(dim(Sig)[1] != dim(Sig)[2]){
        stop("Sig is not a square matrix")
     }
     if(vid>dim(Sig)[1] | vid<=0){
        stop("Wrong vertex index")
     }
  
     connect <- c(connect, vid)
     path <- c(path, vid)
     visited[vid] <- 1

     flag <- 0

     tmp <- which(visited==0)  
	 ranks <- order(-abs(Sig[vid,tmp]))
     rest.ranks <- tmp[ranks]

     for(i in rest.ranks){
       if(Sig[vid,i]!=0 & visited[i]==0 & depth<=m){
	   depth <- depth+1
	   tmp <- con_node(i, Sig, visited=visited, depth=depth, connect=connect, path=path)

	   visited <- tmp$visited
       depth <- tmp$depth
       connect <- tmp$connect
       path <- tmp$path
           flag <-1
        } # end of if        
     } # end of for

     if(flag==0){stop}

     return(list(connect=connect, visited=visited, depth=depth, path=path))
}
